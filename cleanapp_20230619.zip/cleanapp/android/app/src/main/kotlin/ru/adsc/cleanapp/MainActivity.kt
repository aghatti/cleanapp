package ru.adsc.cleanapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
