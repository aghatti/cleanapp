import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class StartPage extends StatelessWidget {
  const StartPage({Key? key}) : super(key: key);

  // TODO: Make a collection of cards (102)
  // TODO: Add a variable for Category (104)
  @override
  Widget build(BuildContext context) {
    // TODO: Return an AsymmetricView (104)
    // TODO: Pass Category variable to AsymmetricView (104)
    return Scaffold(
      // TODO: Add app bar (102)
      // TODO: Add a grid view (102)
      backgroundColor: Theme.of(context).primaryColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/cleanapp_logo_big.png'),
            const SizedBox(height: 10.0),
            Text(
              AppLocalizations.of(context)!.order,
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 10.0),
          FilledButton(
              onPressed: () {
                Navigator.pushNamed(context, '/login');
              },
              style: FilledButton.styleFrom(
                backgroundColor: Color.fromRGBO(126, 123, 244, 1.0),
              ),
              child: Text(AppLocalizations.of(context)!.logIn),
            ),

          ],
        ),
      ),
      // TODO: Set resizeToAvoidBottomInset (101)
    );
  }
}
