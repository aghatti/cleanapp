import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:provider/provider.dart';
import 'package:authentication_repository/authentication_repository.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: Theme.of(context).primaryColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Hello, user.'),
            FilledButton(
              onPressed: () {
                try {
                  Provider.of<AuthenticationRepository>(context, listen: false).logOut();
                  Navigator.pushReplacementNamed(context, '/');
                }
                catch (_) {
                }

              },
              child: Text(AppLocalizations.of(context)!.logOut),
            ),
          ]
        ),
      ),
    );
  }
}
